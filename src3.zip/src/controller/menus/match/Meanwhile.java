package controller.menus.match;

import controller.menus.Menu;

public class Meanwhile extends Menu {

    @Override
    public String getName() {
        return "";
    }

    @Override
    public void handleCommand(String text) {

    }

    @Override
    public void exitMenu() {

    }

    @Override
    public String showMenu() {
        return "";
    }
}
