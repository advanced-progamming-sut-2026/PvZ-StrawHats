package model.collections.item;

import model.match_mechanisms.vector.Position;
import model.user_data.UserState;
import model.utils.GameSession;

public class GroundPlantFood extends GroundItem {

    public GroundPlantFood(Position position) {
        super(ItemType.PLANT_FOOD, position, 15, 0.6);
    }

    @Override
    public void applyRewards(GameSession session, UserState state) {
        session.addPlantFood();
    }
}
